*_-=Word Trivia=-_ Trivia Question File v1.1 by Swent

*Words and definitions compiled by Swent. Last modified by Swent 3:27 PM 6/14/2005

Development Notes:
*Used the 65,000 words found in SocXFiftyTwo's Scramble Bot database.
*Retieved definitions for each word from dictionary.com using a modified Dictionary Script and wrote all to a text file.

Changes:
*Mimimized from 65,000 questions to 18,880 after removing similar definitions (there are still some left...deal with it)
*Removed "See <otherword>" definitions.
*Removed pronounciation keys (they're give-aways...)
*Replaced answers inside questions with "-"'s.
*Truncated over-size definitions and added "..."